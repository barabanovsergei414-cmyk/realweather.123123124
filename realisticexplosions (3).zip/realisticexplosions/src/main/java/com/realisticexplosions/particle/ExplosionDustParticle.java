package com.realisticexplosions.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.*;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ExplosionDustParticle extends TextureSheetParticle {

    private ExplosionDustParticle(ClientLevel level, double x, double y, double z,
                                   double vx, double vy, double vz) {
        super(level, x, y, z, vx, vy, vz);
        float gray = 0.45f + (float)(random.nextDouble() * 0.25);
        float warm = (float)(random.nextDouble() * 0.08);
        this.rCol = gray + warm;
        this.gCol = gray + warm * 0.5f;
        this.bCol = gray;
        this.alpha = 0.85f;
        // Долгая жизнь: 6-10 секунд
        this.lifetime = 120 + random.nextInt(80);
        this.quadSize = 0.4f + (float)(random.nextDouble() * 0.7);
        this.gravity = 0.025f;
        this.xd = vx; this.yd = vy; this.zd = vz;
    }

    @Override
    public void tick() {
        this.xo = this.x; this.yo = this.y; this.zo = this.z;
        // Замедление
        this.xd *= 0.94f;
        this.yd *= 0.94f;
        this.zd *= 0.94f;
        // Гаснет только в последние 30% жизни
        float fade = (float)this.age / this.lifetime;
        if (fade > 0.7f) {
            this.alpha = 0.85f * (1.0f - (fade - 0.7f) / 0.3f);
        }
        this.move(this.xd, this.yd - this.gravity, this.zd);
        if (this.age++ >= this.lifetime) this.remove();
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @OnlyIn(Dist.CLIENT)
    public static class Factory implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        public Factory(SpriteSet sprites) { this.sprites = sprites; }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level,
                                        double x, double y, double z,
                                        double vx, double vy, double vz) {
            ExplosionDustParticle p = new ExplosionDustParticle(level, x, y, z, vx, vy, vz);
            p.pickSprite(sprites);
            return p;
        }
    }
}
