package com.realisticexplosions.render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import com.realisticexplosions.client.ExplosionEffectClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(value = Dist.CLIENT, modid = "realisticexplosions")
public class ExplosionRenderer {

    // ══════════════════════════════════════════════════════════════════════
    //  ТРЯСКА КАМЕРЫ
    // ══════════════════════════════════════════════════════════════════════
    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        if (ExplosionEffectClient.shakePower > 0.01f) {
            event.setYaw((float)(event.getYaw()   + ExplosionEffectClient.shakeX));
            event.setPitch((float)(event.getPitch() + ExplosionEffectClient.shakeY));
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  GUI OVERLAY: вспышка + шейдер ударной волны
    // ══════════════════════════════════════════════════════════════════════
    @SubscribeEvent
    public static void onRenderGui(RenderGuiOverlayEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        int W = mc.getWindow().getGuiScaledWidth();
        int H = mc.getWindow().getGuiScaledHeight();
        PoseStack ps = event.getGuiGraphics().pose();

        // ── Шейдер ударной волны (тёмный виньет по краям) ────────────────
        float shock = ExplosionEffectClient.shockAlpha;
        if (shock > 0.01f) {
            renderVignette(ps, W, H, shock);
        }

        // ── Белая вспышка ─────────────────────────────────────────────────
        float flash = ExplosionEffectClient.flashAlpha;
        if (flash > 0.004f) {
            renderFlash(ps, W, H, flash);
        }

        // ── Хроматическая аберрация (цветные края при сильном взрыве) ────
        if (shock > 0.3f) {
            renderChromaticAberration(ps, W, H, shock);
        }
    }

    private static void renderFlash(PoseStack ps, int W, int H, float alpha) {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        BufferBuilder buf = Tesselator.getInstance().getBuilder();
        buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        int a = (int)(alpha * 255);
        // Тёплый белый — как от вспышки пороха
        buf.vertex(0,0,0).color(255,245,200,a).endVertex();
        buf.vertex(0,H,0).color(255,245,200,a).endVertex();
        buf.vertex(W,H,0).color(255,245,200,a).endVertex();
        buf.vertex(W,0,0).color(255,245,200,a).endVertex();
        Tesselator.getInstance().end();
        RenderSystem.disableBlend();
    }

    private static void renderVignette(PoseStack ps, int W, int H, float alpha) {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        BufferBuilder buf = Tesselator.getInstance().getBuilder();
        buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        int a = (int)(alpha * 180);
        int cx = W/2, cy = H/2;
        // Тёмный виньет по краям — 4 градиентных полосы
        // Сверху
        buf.vertex(0,0,0).color(0,0,0,a).endVertex();
        buf.vertex(0,H/3,0).color(0,0,0,0).endVertex();
        buf.vertex(W,H/3,0).color(0,0,0,0).endVertex();
        buf.vertex(W,0,0).color(0,0,0,a).endVertex();
        // Снизу
        buf.vertex(0,H*2/3,0).color(0,0,0,0).endVertex();
        buf.vertex(0,H,0).color(0,0,0,a).endVertex();
        buf.vertex(W,H,0).color(0,0,0,a).endVertex();
        buf.vertex(W,H*2/3,0).color(0,0,0,0).endVertex();
        // Слева
        buf.vertex(0,0,0).color(0,0,0,a).endVertex();
        buf.vertex(0,H,0).color(0,0,0,a).endVertex();
        buf.vertex(W/3,H,0).color(0,0,0,0).endVertex();
        buf.vertex(W/3,0,0).color(0,0,0,0).endVertex();
        // Справа
        buf.vertex(W*2/3,0,0).color(0,0,0,0).endVertex();
        buf.vertex(W*2/3,H,0).color(0,0,0,0).endVertex();
        buf.vertex(W,H,0).color(0,0,0,a).endVertex();
        buf.vertex(W,0,0).color(0,0,0,a).endVertex();
        Tesselator.getInstance().end();
        RenderSystem.disableBlend();
    }

    private static void renderChromaticAberration(PoseStack ps, int W, int H, float alpha) {
        // Красный слой смещён вправо, синий влево — эффект аберрации
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        BufferBuilder buf = Tesselator.getInstance().getBuilder();
        buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        int a = (int)(alpha * 25);
        int off = (int)(alpha * 6);
        // Красный — правый край
        buf.vertex(W-off*3,0,0).color(255,0,0,a).endVertex();
        buf.vertex(W-off*3,H,0).color(255,0,0,a).endVertex();
        buf.vertex(W,H,0).color(255,0,0,0).endVertex();
        buf.vertex(W,0,0).color(255,0,0,0).endVertex();
        // Синий — левый край
        buf.vertex(0,0,0).color(0,0,255,0).endVertex();
        buf.vertex(0,H,0).color(0,0,255,0).endVertex();
        buf.vertex(off*3,H,0).color(0,0,255,a).endVertex();
        buf.vertex(off*3,0,0).color(0,0,255,a).endVertex();
        Tesselator.getInstance().end();
        RenderSystem.disableBlend();
    }

    // ══════════════════════════════════════════════════════════════════════
    //  3D УДАРНАЯ ВОЛНА (кольцо в мире)
    // ══════════════════════════════════════════════════════════════════════
    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        if (ExplosionEffectClient.SHOCKWAVES.isEmpty()) return;

        Minecraft mc = Minecraft.getInstance();
        Vec3 cam = mc.gameRenderer.getMainCamera().getPosition();
        float partial = event.getPartialTick();
        PoseStack ps = event.getPoseStack();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        for (ExplosionEffectClient.ShockwaveRing ring : ExplosionEffectClient.SHOCKWAVES) {
            drawRing(ps, ring, cam, partial);
        }

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private static void drawRing(PoseStack ps, ExplosionEffectClient.ShockwaveRing ring,
                                  Vec3 cam, float partial) {
        float radius = ring.getRadius(partial);
        float alpha  = ring.getAlpha(partial);
        if (alpha < 0.01f || radius < 0.1f) return;

        ps.pushPose();
        ps.translate(ring.center.x - cam.x, ring.center.y - cam.y, ring.center.z - cam.z);

        int SEG = 64;
        float thick = 0.5f + radius * 0.04f;

        BufferBuilder buf = Tesselator.getInstance().getBuilder();
        buf.begin(VertexFormat.Mode.TRIANGLE_STRIP, DefaultVertexFormat.POSITION_COLOR);

        for (int i = 0; i <= SEG; i++) {
            double angle = 2.0 * Math.PI * i / SEG;
            float cx = (float)Math.cos(angle);
            float cz = (float)Math.sin(angle);
            int a = (int)(alpha * 200);
            // Внешний край — прозрачный
            buf.vertex(cx*(radius+thick), 0, cz*(radius+thick)).color(220,235,255,0).endVertex();
            // Яркий центр кольца
            buf.vertex(cx*radius,         0, cz*radius        ).color(220,235,255,a).endVertex();
        }
        Tesselator.getInstance().end();

        // Внутренний спад
        buf.begin(VertexFormat.Mode.TRIANGLE_STRIP, DefaultVertexFormat.POSITION_COLOR);
        for (int i = 0; i <= SEG; i++) {
            double angle = 2.0 * Math.PI * i / SEG;
            float cx = (float)Math.cos(angle);
            float cz = (float)Math.sin(angle);
            int a = (int)(alpha * 200);
            buf.vertex(cx*radius,              0, cz*radius             ).color(220,235,255,a).endVertex();
            buf.vertex(cx*(radius-thick*0.6f), 0, cz*(radius-thick*0.6f)).color(220,235,255,0).endVertex();
        }
        Tesselator.getInstance().end();

        ps.popPose();
    }
}
