package com.realisticexplosions;

import com.realisticexplosions.event.ExplosionEventHandler;
import com.realisticexplosions.network.NetworkHandler;
import com.realisticexplosions.particle.ExplosionParticles;
import com.realisticexplosions.sound.SoundRegistry;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod("realisticexplosions")
public class RealisticExplosions {

    public static final String MODID = "realisticexplosions";
    public static final Logger LOGGER = LogManager.getLogger();

    public RealisticExplosions() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ExplosionParticles.PARTICLE_TYPES.register(modEventBus);
        SoundRegistry.SOUNDS.register(modEventBus);

        modEventBus.addListener(this::commonSetup);
        modEventBus.addListener(this::clientSetup);

        MinecraftForge.EVENT_BUS.register(new ExplosionEventHandler());
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        NetworkHandler.register();
    }

    private void clientSetup(final FMLClientSetupEvent event) {
        ExplosionParticles.registerFactories();
    }
}
