package com.realisticexplosions.client;

import com.realisticexplosions.particle.ExplosionParticles;
import com.realisticexplosions.sound.SoundRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class ExplosionEffectClient {

    public static final List<ShockwaveRing> SHOCKWAVES = new ArrayList<>();
    // Шейдер-эффекты экрана
    public static float shakePower  = 0;
    public static float shakeX      = 0;
    public static float shakeY      = 0;
    public static float flashAlpha  = 0; // белая вспышка
    public static float shockAlpha  = 0; // радиальное искажение (simulated)
    public static float shockAge    = 0;

    private static final List<DelayedSound> PENDING_SOUNDS = new ArrayList<>();
    private static final Random RNG = new Random();

    // Лимиты частиц за один взрыв
    private static final int MAX_FIRE  = 20;
    private static final int MAX_SMOKE = 35;
    private static final int MAX_DUST  = 40;
    private static final int MAX_SPARK = 25;
    private static final int MAX_EMBER = 15;

    public static void triggerEffect(Vec3 pos, float power, float np,
                                     float dist, int soundDelay) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        // ── Вспышка (только вблизи) ──────────────────────────────────────
        float nearFactor = Math.max(0f, 1f - dist / 24f);
        flashAlpha = Math.min(0.6f, np * nearFactor * 0.5f);

        // ── Шейдер ударной волны ─────────────────────────────────────────
        if (dist < 48f) {
            shockAlpha = Math.min(1f, np * (1f - dist/48f) * 0.9f);
            shockAge   = 0;
        }

        // ── Тряска камеры ─────────────────────────────────────────────────
        float shakeStr = np * Math.max(0f, 1f - dist / 36f);
        shakePower = Math.max(shakePower, shakeStr * 7f);

        // ── Ударная волна (кольцо) ────────────────────────────────────────
        SHOCKWAVES.add(new ShockwaveRing(pos, np));

        // ── Частицы ───────────────────────────────────────────────────────
        // Показываем частицы только если игрок достаточно близко
        if (dist < 128f) spawnFX(mc, pos, np, power);

        // ── Звук с задержкой ──────────────────────────────────────────────
        PENDING_SOUNDS.add(new DelayedSound(pos, np, soundDelay));
    }

    // ══════════════════════════════════════════════════════════════════════
    //  ЧАСТИЦЫ
    // ══════════════════════════════════════════════════════════════════════
    private static void spawnFX(Minecraft mc, Vec3 c, float np, float power) {
        float scale = Math.min(np, 2.5f); // ограничиваем масштаб

        // ── 1. ОГНЕННЫЙ ШАР ──────────────────────────────────────────────
        int fire = Math.min(MAX_FIRE, Math.max(5, (int)(12 * scale)));
        for (int i = 0; i < fire; i++) {
            double ang  = RNG.nextDouble() * Math.PI * 2;
            double elev = (RNG.nextDouble() - 0.1) * Math.PI * 0.5;
            double spd  = 0.15 + RNG.nextDouble() * 0.35 * scale;
            mc.level.addParticle(ParticleTypes.FLAME,
                c.x + (RNG.nextDouble()-0.5) * power * 0.6,
                c.y + RNG.nextDouble() * power * 0.5,
                c.z + (RNG.nextDouble()-0.5) * power * 0.6,
                Math.cos(ang) * Math.cos(elev) * spd,
                Math.abs(Math.sin(elev) * spd) + 0.08,
                Math.sin(ang) * Math.cos(elev) * spd);
        }

        // ── 2. РАСКАЛЁННЫЕ УГЛИ ──────────────────────────────────────────
        int ember = Math.min(MAX_EMBER, (int)(8 * scale));
        for (int i = 0; i < ember; i++) {
            double ang = RNG.nextDouble() * Math.PI * 2;
            double spd = 0.3 + RNG.nextDouble() * 0.6 * scale;
            mc.level.addParticle(ParticleTypes.LAVA,
                c.x, c.y + 0.5, c.z,
                Math.cos(ang) * spd, 0.2 + RNG.nextDouble() * 0.4,
                Math.sin(ang) * spd);
        }

        // ── 3. ЧЁРНЫЙ ДЫМ СТОЛБОМ ────────────────────────────────────────
        int smoke = Math.min(MAX_SMOKE, Math.max(8, (int)(20 * scale)));
        for (int i = 0; i < smoke; i++) {
            double ang = RNG.nextDouble() * Math.PI * 2;
            double r   = RNG.nextDouble() * Math.min(power, 3.0) * 0.8;
            double h   = RNG.nextDouble() * power * 0.5;
            mc.level.addParticle(ExplosionParticles.EXPLOSION_SMOKE.get(),
                c.x + Math.cos(ang) * r,
                c.y + h,
                c.z + Math.sin(ang) * r,
                (RNG.nextDouble()-0.5) * 0.06,
                0.06 + RNG.nextDouble() * 0.14 * scale,
                (RNG.nextDouble()-0.5) * 0.06);
        }
        // Дополнительный дым выше (гриб)
        if (np > 0.7f) {
            int mushroom = Math.min(15, (int)(10 * scale));
            for (int i = 0; i < mushroom; i++) {
                double ang = RNG.nextDouble() * Math.PI * 2;
                double r   = RNG.nextDouble() * power * 0.5;
                double h   = power * 0.6 + RNG.nextDouble() * power * 1.2;
                mc.level.addParticle(ExplosionParticles.EXPLOSION_SMOKE.get(),
                    c.x + Math.cos(ang) * r,
                    c.y + h,
                    c.z + Math.sin(ang) * r,
                    (RNG.nextDouble()-0.5) * 0.12,
                    0.03 + RNG.nextDouble() * 0.06,
                    (RNG.nextDouble()-0.5) * 0.12);
            }
        }

        // ── 4. ПЫЛЬ (низко, горизонтально) ───────────────────────────────
        int dust = Math.min(MAX_DUST, Math.max(8, (int)(25 * scale)));
        for (int i = 0; i < dust; i++) {
            double ang = RNG.nextDouble() * Math.PI * 2;
            double spd = 0.2 + RNG.nextDouble() * 0.6 * scale;
            mc.level.addParticle(ExplosionParticles.EXPLOSION_DUST.get(),
                c.x + (RNG.nextDouble()-0.5) * power * 0.5,
                c.y + RNG.nextDouble() * 1.0,
                c.z + (RNG.nextDouble()-0.5) * power * 0.5,
                Math.cos(ang) * spd,
                RNG.nextDouble() * 0.2,
                Math.sin(ang) * spd);
        }

        // ── 5. ИСКРЫ ─────────────────────────────────────────────────────
        int spark = Math.min(MAX_SPARK, Math.max(5, (int)(15 * scale)));
        for (int i = 0; i < spark; i++) {
            double ang  = RNG.nextDouble() * Math.PI * 2;
            double elev = RNG.nextDouble() * Math.PI * 0.55;
            double spd  = 0.6 + RNG.nextDouble() * 1.4 * scale;
            mc.level.addParticle(ExplosionParticles.EXPLOSION_SPARK.get(),
                c.x, c.y + 0.5, c.z,
                Math.cos(ang) * Math.cos(elev) * spd,
                Math.sin(elev) * spd + 0.15,
                Math.sin(ang) * Math.cos(elev) * spd);
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  ТИК
    // ══════════════════════════════════════════════════════════════════════
    public static void tick() {
        // Тряска
        if (shakePower > 0.01f) {
            shakeX = (float)(RNG.nextGaussian() * shakePower * 0.65);
            shakeY = (float)(RNG.nextGaussian() * shakePower * 0.4);
            shakePower *= 0.70f;
            if (shakePower < 0.01f) { shakePower = 0; shakeX = 0; shakeY = 0; }
        }
        // Вспышка
        if (flashAlpha > 0.004f) {
            flashAlpha *= 0.73f;
            if (flashAlpha < 0.004f) flashAlpha = 0;
        }
        // Шейдер ударной волны
        if (shockAlpha > 0.004f) {
            shockAge++;
            shockAlpha *= 0.80f;
            if (shockAlpha < 0.004f) { shockAlpha = 0; shockAge = 0; }
        }
        // Ударные волны
        SHOCKWAVES.removeIf(r -> { r.tick(); return r.isDead(); });
        // Звуки
        Minecraft mc = Minecraft.getInstance();
        Iterator<DelayedSound> it = PENDING_SOUNDS.iterator();
        while (it.hasNext()) {
            DelayedSound ds = it.next();
            if (--ds.ticksLeft <= 0) {
                playSound(mc, ds);
                it.remove();
            }
        }
    }

    private static void playSound(Minecraft mc, DelayedSound ds) {
        if (mc.level == null) return;
        SoundEvent se;
        float vol;
        if (ds.np < 0.6f)      { se = SoundRegistry.EXPLOSION_SMALL.get();  vol = 3f; }
        else if (ds.np < 1.5f) { se = SoundRegistry.EXPLOSION_MEDIUM.get(); vol = 5f; }
        else if (ds.np < 3.0f) { se = SoundRegistry.EXPLOSION_LARGE.get();  vol = 7f; }
        else                   { se = SoundRegistry.EXPLOSION_HUGE.get();   vol = 10f;}
        float pitch = 0.88f + RNG.nextFloat() * 0.22f;
        mc.level.playLocalSound(ds.pos.x, ds.pos.y, ds.pos.z,
            se, SoundSource.BLOCKS, vol, pitch, false);
    }

    // ══════════════════════════════════════════════════════════════════════
    //  ВСПОМОГАТЕЛЬНЫЕ КЛАССЫ
    // ══════════════════════════════════════════════════════════════════════
    public static class ShockwaveRing {
        public final Vec3 center;
        public final float maxRadius;
        private int age = 0;
        private static final int LIFE = 32;

        public ShockwaveRing(Vec3 c, float np) {
            center = c;
            maxRadius = 3f + 14f * Math.min(np, 3f);
        }
        public void tick() { age++; }
        public boolean isDead() { return age >= LIFE; }
        public float getRadius(float partial) {
            float t = (age + partial) / LIFE;
            return maxRadius * (float)Math.sqrt(Math.min(t, 1f));
        }
        public float getAlpha(float partial) {
            float t = (age + partial) / LIFE;
            float c = Math.min(t, 1f);
            return (1f - c) * (1f - c);
        }
    }

    static class DelayedSound {
        final Vec3 pos; final float np; int ticksLeft;
        DelayedSound(Vec3 p, float n, int t) { pos=p; np=n; ticksLeft=t; }
    }
}
