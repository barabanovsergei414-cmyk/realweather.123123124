package com.realisticexplosions.event;

import com.realisticexplosions.network.NetworkHandler;
import com.realisticexplosions.network.PacketExplosionEffect;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.level.ExplosionEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class ExplosionEventHandler {

    private static final double SHOCKWAVE_RADIUS = 32.0;
    private static final float MAX_DAMAGE = 20.0f;
    // 1 тик = 0.05 сек, скорость звука ~60 блоков/сек
    private static final double SOUND_SPEED = 60.0;
    // Максимальный радиус слышимости/видимости взрыва
    private static final double MAX_EFFECT_DIST = 256.0;

    @SubscribeEvent
    public void onExplosionDetonate(ExplosionEvent.Detonate event) {
        if (!(event.getLevel() instanceof ServerLevel serverLevel)) return;

        Explosion explosion = event.getExplosion();
        Vec3 center = explosion.getPosition();
        float power = getRadius(explosion);
        float normalizedPower = power / 4.0f;

        // Отправляем пакет ВСЕМ игрокам на сервере (не только вблизи)
        for (ServerPlayer player : serverLevel.players()) {
            double dist = player.position().distanceTo(center);
            // Задержка звука: расстояние / скорость звука → тики
            int soundDelayTicks = Math.max(0, (int)(dist / SOUND_SPEED * 20.0));
            NetworkHandler.sendToPlayer(
                new PacketExplosionEffect(center, power, normalizedPower, (float)dist, soundDelayTicks),
                player
            );
        }

        applyShockwave(serverLevel, center, normalizedPower);
    }

    private float getRadius(Explosion explosion) {
        try {
            java.lang.reflect.Field f = Explosion.class.getDeclaredField("radius");
            f.setAccessible(true);
            return f.getFloat(explosion);
        } catch (Exception e) {
            return 4.0f;
        }
    }

    private void applyShockwave(ServerLevel level, Vec3 center, float np) {
        double radius = SHOCKWAVE_RADIUS * np;
        for (Entity entity : level.getEntities(null, new AABB(
                center.x-radius, center.y-radius, center.z-radius,
                center.x+radius, center.y+radius, center.z+radius))) {
            double dist = entity.position().distanceTo(center);
            if (dist > radius || dist < 0.1) continue;
            double falloff = Math.pow(1.0 - dist/radius, 2);
            Vec3 dir = entity.position().subtract(center).normalize();
            entity.setDeltaMovement(entity.getDeltaMovement().add(
                dir.x*3.0*np*falloff,
                dir.y*3.0*np*falloff + 0.4*falloff,
                dir.z*3.0*np*falloff));
            entity.hurtMarked = true;
            if (entity instanceof LivingEntity living) {
                float dmg = (float)(MAX_DAMAGE * np * falloff);
                if (dmg > 0.5f) living.hurt(level.damageSources().explosion(null), dmg);
            }
        }
    }
}
